تطبيق لوحة العرض لـ Android TV
================================
الطريقة 1 (بدون تثبيت أي برنامج) - GitHub Actions:
 1) أنشئ مستودع (repository) جديد في github.com وارفع كل محتويات هذا المجلد (بما فيها مجلد .github).
 2) ادخل تبويب Actions > Build APK > Run workflow.
 3) بعد دقائق نزّل ملف LiveDashboard-TV-apk من أسفل صفحة التشغيل (فيه app-debug.apk).
الطريقة 2 - Android Studio: File > Open على هذا المجلد، ثم Build > Build APK(s).
التثبيت على التلفزيون: انسخ الـ APK على فلاشة أو استخدم تطبيق Send Files to TV أو adb install app-debug.apk
الريموت: يمين/يسار = تنقل بين المربعات | فوق/تحت = سكرول | OK = تبديل بين الجداول داخل المربع
